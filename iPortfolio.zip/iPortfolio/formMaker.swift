

import Foundation
//
//  ViewController.swift
//  iPortfolio
//
//  Created by Rohnit Shetty on 2/23/19.
//  Copyright © 2019 Rohnit Shetty. All rights reserved.
//

import UIKit

import Eureka

class formMaker: FormViewController{
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        createForm()
        print("Name is " + name)
        
        
    }
    
    
    var name: String = ""
    var phone: String = ""
    var email: String = ""
    var linkedIn: URL? = nil
    var bio: String = ""
    var schoolName: String = ""
    var schoolAddress: String = ""
    var course: String = ""
    var gradDate: Date? = nil
    var GPA: Double = 0
    var Skills: Array<String> = []
    
    
    
    func createForm(){
        form +++ Section("Basic Info")
            <<< NameRow(){ row in
                row.title = "Name"
                row.placeholder = "Enter your name"
                }.onChange({ (row) in
                    self.name = row.value != nil ? row.value! : "" //updating the value on change
                    print("Name is " + self.name)
                })
            <<< PhoneRow(){
                $0.title = "Phone Number"
                $0.placeholder = "Enter your phone number"
                $0.add(rule: RuleMaxLength(maxLength: 10, msg: "Invalid Phone Number"))
                $0.validationOptions = .validatesOnChange
                
                }.onChange({ (row) in
                    self.phone = row.value != nil ? row.value! : "" //updating the value on change
                    print("phone is " + self.phone)
                })
            <<< EmailRow(){
                $0.title = "Email"
                $0.placeholder = "Your primary email address"
                $0.add(rule: RuleRequired())
                $0.add(rule: RuleEmail())
                $0.validationOptions = .validatesOnChange
                }.onChange({ (row) in
                    self.email = row.value != nil ? row.value! : "" //updating the value on change
                    print("Email is " + self.email)
                })
            <<< URLRow(){ row in
                row.title = "LinkedIn URL"
                row.placeholder = "Enter your LinkedIn URL"
                }.onChange({ (row) in
                    self.linkedIn = row.value!  //updating the value on change
                    print(self.linkedIn!)
                })
            
            
            +++ Section("Summary/Bio")
            <<< TextAreaRow(){ row in
                row.title = "Bio"
                row.placeholder = "Enter a short Bio"
                }.onChange({ (row) in
                    self.bio = row.value != nil ? row.value! : "" //updating the value on change
                    print("Bio is " + self.bio)
                })
            +++ Section("Education")
            <<< NameRow(){
                $0.title = "School Name"
                $0.placeholder = "Enter School Name"
                }.onChange({ (row) in
                    self.schoolName = row.value != nil ? row.value! : "" //updating the value on change
                    print("School Name is " + self.schoolName)
                })
            <<< TextRow(){
                $0.title = "Address"
                $0.placeholder = "Enter school location"
                
                }.onChange({ (row) in
                    self.schoolAddress = row.value != nil ? row.value! : "" //updating the value on change
                    print("school address is " + self.schoolAddress)
                })
            <<< TextRow(){
                $0.title = "Course"
                $0.placeholder = "Enter course"
                }.onChange({ (row) in
                    self.course = row.value != nil ? row.value! : "" //updating the value on change
                    print("Course is " + self.course)
                })
            <<< DateRow(){
                $0.title = "Graduation Date"
                $0.value = Date(timeIntervalSinceReferenceDate: 0)
                }.onChange({ (row) in
                    self.gradDate = row.value
                    print(self.gradDate as Any)
                })
            <<< DecimalRow(){
                $0.title = "GPA"
                $0.placeholder = "Enter GPA"
                
                }.onChange({ (row) in
                    self.GPA = row.value!
                    print(self.GPA)
                })
            
            
            
            
        
            +++ MultivaluedSection(multivaluedOptions: [.Reorder, .Insert, .Delete],
                               header: "Technical Skills") {
                                $0.addButtonProvider = { section in
                                    return ButtonRow(){
                                        $0.title = "Add a New Skill"
                                    }
                                }
                                $0.multivaluedRowToInsertAt = { index in
                                    return NameRow() {
                                        $0.placeholder = "Skill Name"
                                        }.onChange({ (row) in
                                            self.name = row.value != nil ? row.value! : "" //updating the value on change
                                            print("Name is " + self.name)
                                        })
                                }
                                $0 <<< NameRow() {
                                    $0.placeholder = "Skill Name"
                                    }.onChange({ (row) in
                                        self.name = row.value != nil ? row.value! : "" //updating the value on change
                                        print("Name is " + self.name)
                                    })
        }
            +++ MultivaluedSection(multivaluedOptions: [ .Insert, .Delete],
                                   header: "Experience") {
                                    $0.addButtonProvider = { section in
                                        return ButtonRow(){
                                            $0.title = "Add a New Experience"
                                        }
                                    }
                                    $0.multivaluedRowToInsertAt = { index in
                                        return TextAreaRow() {
                                            $0.placeholder = "Company name \n - Your Tasks"
                                            }.onChange({ (row) in
                                                self.Skills.append(row.value!)
                                                print(self.Skills)
                                            })
                                    }
                                    $0 <<< TextAreaRow() {
                                        $0.placeholder = "Company name \n - Your Tasks"
                                        }.onChange({ (row) in
                                            self.Skills.append(row.value!)
                                            print(self.Skills)
                                        })
        }
        
    }
    
    
}




